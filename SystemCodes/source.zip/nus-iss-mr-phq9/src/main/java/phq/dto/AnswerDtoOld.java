package phq.dto;

public class AnswerDtoOld {
    private String firstLevel = "Not At all";
    private String secondLevel = "Several Days";
    private String thirdLevel = "More Than Half the Days";
    private String fourthLevel = "Nearly Every Day";

    public String getFirstLevel() {
        return firstLevel;
    }

    public String getSecondLevel() {
        return secondLevel;
    }

    public String getThirdLevel() {
        return thirdLevel;
    }

    public String getFourthLevel() {
        return fourthLevel;
    }
}

